import numpy as np
import pandas as pd
import yfinance as yf
from tensorflow.keras.models import load_model
import streamlit as st
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler

# Load the model
model_path = 'C:/Users/adnan/Python/Jupyter Notebook/stock_prediction/Stock Prediction Model.keras'
model = load_model(model_path)

# Streamlit App Header
st.header('Stock Price Prediction')

# User Input: Stock Symbol and Future Days to Predict
stock = st.text_input('Enter Stock Symbol', 'GOOG')
future_days = st.slider('Select Number of Future Days to Predict', min_value=1, max_value=30, value=7)

# Date Range for Historical Data
start = '2014-01-01'
end = '2024-08-30'

# Fetching Stock Data from Yahoo Finance
try:
    data = yf.download(stock, start, end)
    if data.empty:
        st.error('Invalid stock symbol. Please try again.')
        st.stop()  # Stop execution if no data is retrieved
except Exception as e:
    st.error(f'An error occurred: {e}')

# Displaying the Data
st.subheader('Stock Data')
st.write(data)

# Split Data into Training and Testing Sets
data_train = data['Close'][0:int(len(data) * 0.80)]
data_test = data['Close'][int(len(data) * 0.80):]

# Scaling the Data
scaler = MinMaxScaler(feature_range=(0, 1))
train_scaled = scaler.fit_transform(data_train.values.reshape(-1, 1))
test_scaled = scaler.transform(data_test.values.reshape(-1, 1))

# Prepare Input Data for Future Predictions
past_100_days = data['Close'].tail(100).values.reshape(-1, 1)
scaled_past_100 = scaler.transform(past_100_days)
x_input = scaled_past_100.reshape(1, 100, 1)

# Generate Future Predictions
future_predictions = []
for _ in range(future_days):
    pred = model.predict(x_input, verbose=0)
    future_predictions.append(pred[0][0])
    
    # Update x_input with the new prediction
    pred_reshaped = np.array(pred[0][0]).reshape(1, 1, 1)
    x_input = np.append(x_input[:, 1:, :], pred_reshaped, axis=1)

# Rescale Predicted Values to Original Range
future_predictions = scaler.inverse_transform(np.array(future_predictions).reshape(-1, 1))

# Create DataFrame for Future Predictions
future_dates = pd.date_range(start=data.index[-1] + pd.Timedelta(days=1), periods=future_days)
future_df = pd.DataFrame(future_predictions, index=future_dates, columns=['Predicted Price'])

# Display Future Predictions
st.subheader('Future Price Predictions')
st.write(future_df)

# Plot Historical and Future Prices
st.subheader('Historical vs Future Price Prediction')
fig1 = plt.figure(figsize=(10, 6))
plt.plot(data['Close'], label='Historical Prices', color='blue')
plt.plot(future_df, label='Future Predictions', color='red')
plt.xlabel('Date')
plt.ylabel('Price')
plt.legend()
st.pyplot(fig1)

# Plot Moving Averages
# Moving Averages Plot
st.subheader('Price vs Moving Averages')
ma_50 = data['Close'].rolling(50).mean()
ma_100 = data['Close'].rolling(100).mean()
ma_200 = data['Close'].rolling(200).mean()

fig2 = plt.figure(figsize=(10, 6))
plt.plot(data['Close'], label='Close Price', color='green')
plt.plot(ma_50, label='50-Day MA', color='red')
plt.plot(ma_100, label='100-Day MA', color='blue')
plt.plot(ma_200, label='200-Day MA', color='orange')

plt.xlabel('Date')
plt.ylabel('Price')
plt.legend()
plt.grid(True)  # Optional: Add grid for better readability
plt.close(fig2)  # Ensure figure is closed to avoid accumulation

st.pyplot(fig2)


# Prepare Data for Model Evaluation (Original vs Predicted)
x, y = [], []
for i in range(100, train_scaled.shape[0]):
    x.append(train_scaled[i - 100:i])
    y.append(train_scaled[i, 0])

x, y = np.array(x), np.array(y)

# Predict Prices on Training Data
train_predictions = model.predict(x)
train_predictions = scaler.inverse_transform(train_predictions)
y = scaler.inverse_transform(y.reshape(-1, 1))

# Plot Original vs Predicted Prices
st.subheader('Original vs Predicted Prices (Training Data)')
fig3 = plt.figure(figsize=(10, 6))
plt.plot(y, label='Original Price', color='green')
plt.plot(train_predictions, label='Predicted Price', color='red')
plt.xlabel('Time')
plt.ylabel('Price')
plt.legend()
st.pyplot(fig3)
